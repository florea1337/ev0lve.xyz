
#include <util/fnv1a.h>

namespace util
{
	uint32_t runtime_basis = fnv1a_seed;
}
